const express = require('express')
const fs = require('fs');

const app = express();
const PORT = process.env.port || 3001;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Create a list of routes

// Get Route
// A GET Route for all the notes
app. get('/api/notes', (req, res)=>{
    fs.readFile('./db/db.json', 'utf-8', (err, data) =>{
        if (err) throw err;
        const parsedData = JSON.parse(data);
     res.json(parsedData);
    });
});
// Post Route
app. post('/api/notes', (req, res)=>{
    fs.readFile('./db/db.json', 'utf-8', (err, data) =>{
        if (err) throw err;
        const parsedData = JSON.parse(data);
        const newNote = req.body;
        parsedData.push(newNote);
        fs.writeFile('./db/db.json', JSON.stringify(parsedData), (err) =>{
            if (err) throw err;
            res.json(parsedData);
        });
     //res.json(parsedData);
    });
});
// Delete Route

app.listen(PORT, ()=> console.log(`Listening on PORT: ${PORT}`));