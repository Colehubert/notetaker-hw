const express = require('express')
const fs = require('fs');
const cors = require('cors')
const path = require('path')

const app = express();
const PORT = process.env.port || 3001;
app.use(cors());
//app.use( express.static(__dirname ));
app.use("/db", express.static(path.join(__dirname, "../db")));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use("/api",express.static('api'));
app.use("/assets",express.static('assets'))
app.use(express.static('setup'));
// Create a list of routes
app.use('/', (req, res)=>{
    res.sendFile(__dirname + "/setup/index.html");
});
// Get Route
// A GET Route for all the notes
app.get('api/notes', (req, res)=>{
    console.log('a')
    fs.readFile('../db/db.json', 'utf-8', (err, data) =>{
        if (err) throw err;
        const parsedData = JSON.parse(data);
        res.json(parsedData);
    });
   // res.sendFile(__dirname + "/index.html");


});
// Post Route
app.post('/api/notes.js', (req, res)=>{
    console.log('b')
    fs.readFile('../db/db.json', 'utf-8', (err, data) =>{
        if (err) throw err;
        const parsedData = JSON.parse(data);
        const newNote = req.body;
        parsedData.push(newNote);
        fs.writeFile('./db/db.json', JSON.stringify(parsedData), (err) =>{
            if (err) throw err;
         //   res.json(parsedData);
        });
     //res.json(parsedData);
    });
    res.end('done')
});

// Delete Route

app.listen(PORT, ()=> console.log(`Listening on PORT: ${PORT}`));